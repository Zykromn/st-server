// Imports and consts
const bcrypt = require("bcryptjs");

const dbms = require('../dbms');
const dbDriver = new dbms();
require('dotenv').config();

const passwords = 'passwords';
const userdata = 'userdata';
const admins = 'admins'
const fs = require('fs');
const path = require('path');
const { log } = require("console");

// Main class
class userdataController {
    async add_ephones(req, res){
        try{
            const { id, password, phones } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                await dbDriver.update(userdata, {'emergencyphones': phones}, {'id': id});
                return res.status(201).send();
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async get_ephones(req, res){
        try{
            const { id, password } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                const result = await dbDriver.select(userdata, ['emergencyphones'], {'id': id});
                return res.status(200).json(result[0]);
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async get_name(req, res){
        try{
            const { id, password } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                const result = await dbDriver.select(userdata, ['name'], {'id': id});
                return res.status(200).json(result[0]);
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async get_points(req, res){
        try{
            const { id, password } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                const points = await dbDriver.select(userdata, ['points'], {'id': id});
                return res.status(200).json(points[0]);
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async add_points(req, res){
        try{
            const { id, password, points } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                await dbDriver.update(userdata, {'points': points}, {'id': id});
                return res.status(201).send();
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async get_role(req, res){
        try{
            const { id, password } = req.body;
    
            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exist');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                const result = await dbDriver.select(admins, ['flag'], {'id': id});
                                
                if(result[0].flag === '1'){
                    const filePath = path.join(__dirname, '../public/form.html');
                    
                    // Читаем файл и отправляем его как ответ
                    fs.readFile(filePath, (err, data) => {
                        if (err) {
                            console.error(err);
                            return res.status(500).send('Error reading file');
                        }
                        res.writeHead(200, { 'Content-Type': 'text/html' });
                        res.end(data);
                    });
                } else {
                    // Отправка скрипта с алертом и перенаправлением на главную страницу
                    res.send(`
                        <script>
                            alert('You are not an admin.');
                            window.location.href = '/'; // Замените на URL вашей главной страницы
                        </script>
                    `);
                }
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e);
            return res.status(403).send();
        }
    }
}

module.exports = new userdataController;
