// Imports and consts
const bcrypt = require("bcryptjs");

const dbms = require('../dbms');
const dbDriver = new dbms();
require('dotenv').config();

const passwords = 'passwords';
const forum = 'forum';


// Main class
class forumController {
    async add_comment(req, res){
        try{
            const { id, password, comment, hashtag } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                const timestamp = new Date().getTime();
                await dbDriver.insert(forum, {'id': id, 'comment': comment, 'hashtag': hashtag, 'timestamp': timestamp});
                return res.status(200).send();
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async get_comment(req, res){
        try{
            const result = await dbDriver.select(forum);
            return res.status(200).json(result);
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }
}

module.exports = new forumController;
