// Imports and consts
const bcrypt = require("bcryptjs");

const dbms = require('../dbms');
const dbDriver = new dbms();
require('dotenv').config();

const passwords = 'passwords';
const poster = 'poster';


// Main class
class posterController {
    async get_posters(req, res){
        try{
            const result = await dbDriver.select(poster);
            return res.status(200).json(result);
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async add_posters(req, res){
        try{
            const { id, password, title, description, image } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                const timestamp = new Date().getTime();
                await dbDriver.insert(poster, {'id': id, 'timestamp': timestamp, 'title': title, 'description': description, 'image': image});
                return res.status(201).send();
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }
}

module.exports = new posterController;
