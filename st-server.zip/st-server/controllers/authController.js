// Imports and consts
const bcrypt = require("bcryptjs");

const dbms = require('../dbms');
const dbDriver = new dbms();
require('dotenv').config();

const passwords = 'passwords';
const userdata = 'userdata';
const admins = 'admins';

// Main class
class authController {
    async registration(req, res){
        try{
            const { id, password, name } = req.body;

            const result = await dbDriver.select(passwords, ['*'], {'id': id});
            if (result[0]) {
                return res.status(401).send('This account already exists');
            }

            const hashedPassword = bcrypt.hashSync(password, Number(process.env.DB_HASHSALT));
            await dbDriver.insert(passwords, {'id': id, 'hash': hashedPassword});
            await dbDriver.insert(userdata, {'id': id, 'name': name, 'points': 100});
            await dbDriver.insert(admins, {'id': id, 'flag': 0});

            return res.status(201).send();
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }

    async login(req, res){
        try{
            const { id, password } = req.body;

            const hashedPassword = await dbDriver.select(passwords, ['hash'], {'id': id});
            if (!hashedPassword[0]) {
                return res.status(401).send('This account does not exists');
            }
            const passwordsComparison = bcrypt.compareSync(password, hashedPassword[0].hash);
            if (passwordsComparison) {
                return res.status(202).send();
            } else {
                return res.status(401).send('Wrong password');
            }
        } catch (e){
            console.log(e)
            return res.status(403).send()
        }
    }
}

module.exports = new authController;
