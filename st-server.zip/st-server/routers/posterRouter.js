// Imports and consts
const express = require('express');
const posterController = require('../controllers/posterController.js');

const posterRouter = new express();


// Router settings
posterRouter.get('/get/posters', posterController.get_posters);
posterRouter.post('/add/posters', posterController.add_posters);

module.exports = posterRouter;
