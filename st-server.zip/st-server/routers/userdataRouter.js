// Imports and consts
const express = require('express');
const userdataController = require('../controllers/userdataController.js');

const userdataRouter = new express();


// Router settings
userdataRouter.post('/add/ephone', userdataController.add_ephones);
userdataRouter.post('/get/ephone', userdataController.get_ephones);
userdataRouter.post('/get/name', userdataController.get_name);
userdataRouter.post('/get/points', userdataController.get_points);
userdataRouter.post('/add/points', userdataController.add_points);
userdataRouter.post('/get/role', userdataController.get_role);

module.exports = userdataRouter;
