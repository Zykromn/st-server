// Imports and consts
const express = require('express');
const authController = require('../controllers/authController.js');

const authRouter = new express();


// Router settings
authRouter.post('/registration', authController.registration);
authRouter.post('/login', authController.login);

module.exports = authRouter;
