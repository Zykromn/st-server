// Imports and consts
const express = require('express');
const forumController = require('../controllers/forumController.js');

const forumRouter = new express();


// Router settings
forumRouter.post('/add/comment', forumController.add_comment);
forumRouter.get('/get/comment', forumController.get_comment);

module.exports = forumRouter;
