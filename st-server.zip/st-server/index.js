// Imports and consts
const express = require('express');
const cors = require('cors');
const http = require('http');
require('dotenv').config();

const authRouter = require('./routers/authRouter');
const userdataRouter = require('./routers/userdataRouter');
const forumRouter = require('./routers/forumRouter');
const posterRouter = require('./routers/posterRouter');
const path = require('path');

// Server settings
const app = express();
const port = process.env.SERVER_PORT || 7100;
app.use(cors());
app.use(express.static('public'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.use('/auth', authRouter);
app.use('/account', userdataRouter);
app.use('/forum', forumRouter);
app.use('/poster', posterRouter);


// Server launch
async function server(){
    try{
        http.createServer(app).listen(port, () => {
            console.log(`
==================== HTTP server started ===================
PORT - ${port}
============================================================
            `);
        })
    } catch (e) {
        console.log(`
================ Server working error ================
${e}
======================================================
        `);
    }
}
server();
