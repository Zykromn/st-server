// Modules
const { Client } = require('pg');
require('dotenv').config();


// Main class
class dbms{
    constructor(){
        this.driver = new Client({
            host: process.env.DB_HOST,
            port: process.env.DB_PORT,
            user: process.env.DB_USER,
            password: process.env.DB_USER_PASSWORD,
            database: process.env.DB_DATABASE,
        })
        this.connection = this.driver.connect().catch((e) => {
            throw e;
        });

        this.passwords = 'passwords';
        this.userdata = 'userdata';
        this.forum = 'forum';
        this.poster = 'poster';
        this.admins = 'admins';
    }

    async select(tablename, columns = ['*'], conditions = {}) {
        try{
            const columnsReq = columns.join(', ');
            let query = `SELECT ${columnsReq} FROM ${this[tablename]}`;

            if (Object.keys(conditions).length > 0) {
                let conditionsReqList = [];
                Object.keys(conditions).forEach((field, _index) => {
                    conditionsReqList.push(`${field}='${conditions[field]}'`);
                });

                query += ` WHERE ${conditionsReqList.join(' AND ')}`;
            }

            query += ';';
            const result = await this.driver.query(query);
            return result.rows;
        } catch (e) {
            throw e;
        }
    }

    async insert(tablename, props) {
        try{
            let columns = []
            let values = [];
            Object.keys(props).forEach((field, _index) => {
                columns.push(field);
                values.push(props[field]);
            });

            values.map((value, index) => {
                values[index] = `'${value}'`;
            })
            const columnsReq = columns.join(', ');
            const valuesReq = values.join(', ');

            let query = `INSERT INTO ${this[tablename]} (${columnsReq}) VALUES (${valuesReq});`;
            const result = await this.driver.query(query);
            return result.rowCount;
        } catch (e) {
            throw e;
        }
    }

    async update(tablename, props, conditions = {}) {
        try{
            let edits = []
            Object.keys(props).forEach((field, _index) => {
                edits.push(`${field}='${props[field]}'`);
            });
            const editsReq = edits.join(', ');
            let query = `UPDATE ${this[tablename]} SET ${editsReq}`;

            if (Object.keys(conditions).length > 0) {
                let conditionsReqList = [];
                Object.keys(conditions).forEach((field, _index) => {
                    conditionsReqList.push(`${field}='${conditions[field]}'`);
                });

                query += ` WHERE ${conditionsReqList.join(' AND ')}`;
            }

            query += `;`;
            const result = await this.driver.query(query);
            return result.rowCount;
        } catch (e) {
            throw e;
        }
    }

    async delete(tablename, conditions) {
        try{
            let conditionsReqList = [];
            Object.keys(conditions).forEach((field, _index) => {
                conditionsReqList.push(`${field}='${conditions[field]}'`);
            });
            let conditionsReq = conditionsReqList.join(' AND ');


            let query = `DELETE FROM ${this[tablename]} WHERE ${conditionsReq};`;
            const result = await this.driver.query(query);
            return result.rowCount;
        } catch (e) {
            throw e;
        }
    }
}


module.exports = dbms;
